import type { FlagsConfiguration } from '../configuration/configuration';
import type { RandomizationActivation } from '../configuration/prepared-activation';
export type ExperimentationOptOutModeValue = 'disabled' | 'immediate' | 'future_experiments_only';
export type ExperimentationOptOutOption = boolean | ExperimentationOptOutModeValue;
export interface OptOutInstant {
    readonly seconds: number;
    readonly fraction: string;
}
export type ExperimentationOptOutPolicy = false | {
    mode: 'immediate' | 'future_experiments_only';
    cutoff: OptOutInstant;
};
/** Parse the supported timestamp subset, normalizing to nanosecond precision. */
export declare function parseOptOutInstant(value: unknown): OptOutInstant | undefined;
export declare function compareOptOutInstants(left: OptOutInstant, right: OptOutInstant): number;
export declare function experimentationOptOutPolicy(context: Record<string, unknown>, mode?: ExperimentationOptOutOption): ExperimentationOptOutPolicy | undefined;
/** Only an opted-out subject in future mode needs activation metadata. */
export declare function needsActivation(policy: ExperimentationOptOutPolicy | boolean): boolean;
export declare function excludesExperimentAt(policy: ExperimentationOptOutPolicy | boolean, doLog: boolean, activation: RandomizationActivation): boolean;
export declare function experimentationOptOutCacheKey(policy: ExperimentationOptOutPolicy): string;
export declare const INVALID_EXPERIMENTATION_OPT_OUT = "Set dd_experimentation_opt_out_at to YYYY-MM-DDTHH:mm:ss[.fraction] with Z or +/-HH:mm, or omit the attribute";
/** Validates the customer-owned opt-out timestamp without interpreting its age. */
export declare function hasExperimentationOptOut(context: Record<string, unknown>): boolean | undefined;
/** Checks that a precomputed snapshot used the requested exclusion policy, including disabled mode. */
export declare function acknowledgesExperimentationOptOut(configuration: FlagsConfiguration | undefined, policy: ExperimentationOptOutPolicy): boolean;
//# sourceMappingURL=experimentation-opt-out.d.ts.map