import type { EvaluationContext, FlagValueType, Logger, ResolutionDetails } from '@openfeature/core';
import type { FlagTypeToValue } from '../configuration';
import type { VariationType } from '../configuration/generated/ufc_pb';
import type { PreparedRulesResponse } from '../configuration/prepared-rules-response';
import { type TimeStamp } from '../time';
import { type ExperimentationOptOutPolicy } from './experimentation-opt-out';
export type ResolveProtobufFlagEvaluation = (flagKey: string) => string | undefined;
export declare function evaluateProtobufConfiguration<T extends FlagValueType>(configuration: PreparedRulesResponse, type: T, flagKey: string, defaultValue: FlagTypeToValue<T>, context: EvaluationContext, logger: Logger, evaluationTimestampMs?: TimeStamp, excludeExperiments?: ExperimentationOptOutPolicy | boolean, resolveFlagEvaluation?: ResolveProtobufFlagEvaluation): ResolutionDetails<FlagTypeToValue<T>>;
export declare function protobufVariationTypeToFlagValueType(variationType: VariationType): FlagValueType;
//# sourceMappingURL=evaluateProtobufConfiguration.d.ts.map