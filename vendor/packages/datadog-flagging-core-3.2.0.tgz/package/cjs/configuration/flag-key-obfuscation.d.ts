declare const SCHEME = "flag-key-sha256-v1";
/** Capabilities supported by the precomputed parser and evaluator. @internal */
export declare const SUPPORTED_FLAGS_CAPABILITIES: readonly ["assignment-encoding-flag-key-256-v1"];
/** Public metadata stored with the encoded assignment map. @internal */
export type FlagKeyObfuscation = {
    scheme: typeof SCHEME;
    salt: string;
};
/** Validate the response's encoding before parsing or looking up assignments. */
export declare function readFlagKeyObfuscation(obfuscated: unknown, obfuscation: unknown): {
    encoding?: FlagKeyObfuscation;
} | {
    error: string;
};
/** Hash only the lookup key. Values and telemetry retain their original meaning. */
export declare function encodePrecomputedFlagKey(key: string, encoding: FlagKeyObfuscation): {
    key: string;
} | {
    error: string;
};
/** Check the exact byte length and alphabet of a hex-encoded wire value. */
export declare function isLowercaseHex(value: unknown, bytes: number): value is string;
export {};
//# sourceMappingURL=flag-key-obfuscation.d.ts.map