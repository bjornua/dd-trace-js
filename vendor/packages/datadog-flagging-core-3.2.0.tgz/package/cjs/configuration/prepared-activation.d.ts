import { type OptOutInstant } from '../evaluation/experimentation-opt-out';
import type { Allocation, Flag, UniversalFlagConfigurationV1 } from '../evaluation/ufc-v1';
export type RandomizationActivation = {
    kind: 'missing';
} | {
    kind: 'valid';
    instant: OptOutInstant;
} | {
    kind: 'invalid';
};
export type PreparedAllocations<T> = {
    /** False when any activation is invalid, including on unreachable allocations. */
    readonly valid: boolean;
    readonly allocations: ReadonlyArray<{
        allocation: T;
        activation: RandomizationActivation;
    }>;
};
/** Validate every allocation, including unreachable ones, before evaluating any subject. */
export declare function prepareAllocations<T>(allocations: readonly T[], activationFor: (allocation: T) => RandomizationActivation): PreparedAllocations<T>;
/**
 * Prepare a received JSON configuration. Configurations are snapshots: replace changed
 * flags instead of mutating them after preparation. Nothing is added to the wire data.
 */
export declare function prepareUniversalFlagConfiguration(configuration: UniversalFlagConfigurationV1): UniversalFlagConfigurationV1;
/** Raw low-level callers retain one-time preparation; providers prepare eagerly on receipt. */
export declare function prepareJsonFlagActivations(flag: Flag): PreparedAllocations<Allocation>;
//# sourceMappingURL=prepared-activation.d.ts.map