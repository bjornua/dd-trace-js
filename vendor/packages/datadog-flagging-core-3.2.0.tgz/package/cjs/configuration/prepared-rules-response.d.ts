import type { FlagValue } from '@openfeature/core';
import type { Allocation, Flag, FlagsConfiguration as ProtobufFlagsConfiguration } from './generated/ufc_pb';
import { type PreparedAllocations } from './prepared-activation';
export type CachedJsonValue = {
    valid: true;
    value: FlagValue;
} | {
    valid: false;
};
export type PreparedRulesResponse = ProtobufFlagsConfiguration & {
    evaluationRegexCache: Map<number, RegExp | null>;
    evaluationJsonCache: Map<number, CachedJsonValue>;
    /** Validated once at decode time; evaluation must not read raw activation timestamps. */
    randomizationActivations: ReadonlyMap<Flag, PreparedAllocations<Allocation>>;
};
export declare function prepareRulesResponse(response: ProtobufFlagsConfiguration): PreparedRulesResponse;
//# sourceMappingURL=prepared-rules-response.d.ts.map