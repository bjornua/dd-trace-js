/** Builds a flagging CDN host after validating the Datadog site. Does not make a request. */
export declare function buildEndpointHost(site: string, customerDomain?: string): string;
//# sourceMappingURL=endpoint.d.ts.map